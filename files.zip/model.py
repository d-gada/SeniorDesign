"""
model.py
--------
BirdMAE — Masked Autoencoder built on a BirdNET-compatible EfficientNet backbone.

Architecture:
  Encoder : EfficientNet-B0 (pretrained, optionally frozen) used as a patch
            feature extractor.  We split the spectrogram into non-overlapping
            patches, encode each patch independently, then mask a fraction
            before the transformer processing stage.
  Decoder : Lightweight transformer that reconstructs masked patches in
            spectrogram (pixel) space.
  Head    : Optional classification head for fine-tuning.

The design follows MAE (He et al. 2021) adapted for 2-D audio spectrograms.
"""

import math
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
import timm


# ─────────────────────────────────────────────────────────────────────────────
# Positional encoding
# ─────────────────────────────────────────────────────────────────────────────

def sinusoidal_2d_pos_embed(
    embed_dim: int,
    grid_h:   int,
    grid_w:   int,
) -> torch.Tensor:
    """
    Build a 2-D sinusoidal positional embedding of shape (grid_h*grid_w, embed_dim).
    Encodes time (width) and frequency (height) axes independently.
    """
    assert embed_dim % 4 == 0, "embed_dim must be divisible by 4"
    half = embed_dim // 2

    def _1d(length, d):
        pos = torch.arange(length, dtype=torch.float32).unsqueeze(1)
        dim = torch.arange(0, d, 2, dtype=torch.float32)
        omega = 1.0 / (10000 ** (dim / d))
        enc   = torch.zeros(length, d)
        enc[:, 0::2] = torch.sin(pos * omega)
        enc[:, 1::2] = torch.cos(pos * omega)
        return enc  # (length, d)

    row_enc = _1d(grid_h, half)   # (H, D/2)
    col_enc = _1d(grid_w, half)   # (W, D/2)

    # Broadcast to (H, W, D)
    row_enc = row_enc.unsqueeze(1).expand(-1, grid_w, -1)
    col_enc = col_enc.unsqueeze(0).expand(grid_h, -1, -1)
    pos_emb = torch.cat([row_enc, col_enc], dim=-1)   # (H, W, D)
    return pos_emb.view(grid_h * grid_w, embed_dim)


# ─────────────────────────────────────────────────────────────────────────────
# Patchify / Unpatchify helpers
# ─────────────────────────────────────────────────────────────────────────────

def patchify(imgs: torch.Tensor, patch_size: int) -> torch.Tensor:
    """
    imgs : (B, 1, H, W)
    Returns patches : (B, num_patches, patch_size^2)
    """
    B, C, H, W = imgs.shape
    assert H % patch_size == 0 and W % patch_size == 0
    h = H // patch_size
    w = W // patch_size
    x = imgs.reshape(B, C, h, patch_size, w, patch_size)
    x = x.permute(0, 2, 4, 3, 5, 1)               # (B, h, w, p, p, C)
    x = x.reshape(B, h * w, patch_size * patch_size * C)
    return x


def unpatchify(patches: torch.Tensor, patch_size: int, H: int, W: int) -> torch.Tensor:
    """
    patches : (B, num_patches, patch_size^2)  — single channel assumed
    Returns  : (B, 1, H, W)
    """
    B   = patches.shape[0]
    h   = H // patch_size
    w   = W // patch_size
    x   = patches.reshape(B, h, w, patch_size, patch_size, 1)
    x   = x.permute(0, 5, 1, 3, 2, 4)             # (B, 1, h, p, w, p)
    img = x.reshape(B, 1, H, W)
    return img


# ─────────────────────────────────────────────────────────────────────────────
# Patch encoder (EfficientNet feature extractor per-patch)
# ─────────────────────────────────────────────────────────────────────────────

class PatchEncoder(nn.Module):
    """
    Wraps a BirdNET-compatible EfficientNet-B0 to produce a fixed-size
    embedding for each (patch_size × patch_size) spectrogram patch.

    We extract features from the early stem of EfficientNet rather than
    the full network (patches are too small for the full depth).
    """

    def __init__(
        self,
        embed_dim:  int  = 256,
        patch_size: int  = 16,
        freeze:     bool = False,
    ):
        super().__init__()
        self.patch_size = patch_size

        # EfficientNet-B0 expects 3-channel input; we adapt with a conv
        backbone = timm.create_model(
            "efficientnet_b0",
            pretrained=True,
            features_only=True,
            out_indices=(0,),        # only first feature map (~stride-2)
        )
        # Adapt the stem's first conv for 1-channel (grayscale) spectrograms
        old_conv = backbone.conv_stem
        backbone.conv_stem = nn.Conv2d(
            1, old_conv.out_channels,
            kernel_size=old_conv.kernel_size,
            stride=old_conv.stride,
            padding=old_conv.padding,
            bias=False,
        )
        # Initialise from the mean of the pretrained RGB weights
        with torch.no_grad():
            backbone.conv_stem.weight.copy_(old_conv.weight.mean(dim=1, keepdim=True))

        self.backbone = backbone
        if freeze:
            for p in self.backbone.parameters():
                p.requires_grad_(False)

        # Determine backbone output channels by a dummy forward pass
        with torch.no_grad():
            dummy  = torch.zeros(1, 1, patch_size, patch_size)
            out    = self.backbone(dummy)
            feat   = out[0]  # (1, C, h', w')
            in_ch  = feat.shape[1] * feat.shape[2] * feat.shape[3]

        self.proj = nn.Linear(in_ch, embed_dim)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, patch: torch.Tensor) -> torch.Tensor:
        """
        patch : (B * num_visible, 1, P, P)
        returns : (B * num_visible, embed_dim)
        """
        feats = self.backbone(patch)[0]              # (N, C, h, w)
        feats = feats.flatten(1)                     # (N, C*h*w)
        return self.norm(self.proj(feats))


# ─────────────────────────────────────────────────────────────────────────────
# Transformer components
# ─────────────────────────────────────────────────────────────────────────────

class TransformerBlock(nn.Module):
    """Standard pre-norm transformer block."""

    def __init__(self, dim: int, n_heads: int, mlp_ratio: float = 4.0, dropout: float = 0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn  = nn.MultiheadAttention(dim, n_heads, dropout=dropout, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        mlp_dim    = int(dim * mlp_ratio)
        self.mlp   = nn.Sequential(
            nn.Linear(dim, mlp_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_dim, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.norm1(x)
        x = x + self.attn(h, h, h, need_weights=False)[0]
        x = x + self.mlp(self.norm2(x))
        return x


# ─────────────────────────────────────────────────────────────────────────────
# BirdMAE
# ─────────────────────────────────────────────────────────────────────────────

class BirdMAE(nn.Module):
    """
    Masked Autoencoder for Amazonian bird call spectrograms.

    Parameters
    ----------
    img_h, img_w   : spectrogram dimensions (default 128 × 224)
    patch_size     : spatial size of each patch in pixels
    embed_dim      : encoder token dimension
    enc_depth      : number of transformer blocks in encoder
    dec_depth      : number of transformer blocks in decoder
    dec_dim        : decoder token dimension (usually < embed_dim)
    n_heads_enc    : attention heads in encoder
    n_heads_dec    : attention heads in decoder
    mask_ratio     : fraction of patches to mask during pre-training
    freeze_backbone: freeze BirdNET EfficientNet weights
    """

    def __init__(
        self,
        img_h:          int   = 128,
        img_w:          int   = 224,
        patch_size:     int   = 16,
        embed_dim:      int   = 256,
        enc_depth:      int   = 6,
        dec_depth:      int   = 4,
        dec_dim:        int   = 128,
        n_heads_enc:    int   = 8,
        n_heads_dec:    int   = 4,
        mask_ratio:     float = 0.75,
        freeze_backbone: bool = False,
    ):
        super().__init__()
        assert img_h % patch_size == 0 and img_w % patch_size == 0
        self.img_h      = img_h
        self.img_w      = img_w
        self.patch_size = patch_size
        self.mask_ratio = mask_ratio
        self.embed_dim  = embed_dim

        self.grid_h     = img_h // patch_size
        self.grid_w     = img_w // patch_size
        self.num_patches = self.grid_h * self.grid_w

        # ── Encoder ──────────────────────────────────────────────────────────
        self.patch_encoder = PatchEncoder(embed_dim, patch_size, freeze=freeze_backbone)
        self.enc_blocks    = nn.ModuleList([
            TransformerBlock(embed_dim, n_heads_enc) for _ in range(enc_depth)
        ])
        self.enc_norm = nn.LayerNorm(embed_dim)

        # ── Positional embeddings (sinusoidal, frozen) ────────────────────────
        pos = sinusoidal_2d_pos_embed(embed_dim, self.grid_h, self.grid_w)
        self.register_buffer("pos_embed", pos)  # (num_patches, D)

        # Mask token
        self.mask_token = nn.Parameter(torch.zeros(1, 1, dec_dim))
        nn.init.trunc_normal_(self.mask_token, std=0.02)

        # ── Decoder ──────────────────────────────────────────────────────────
        self.enc_to_dec   = nn.Linear(embed_dim, dec_dim, bias=False)
        pos_dec           = sinusoidal_2d_pos_embed(dec_dim, self.grid_h, self.grid_w)
        self.register_buffer("pos_embed_dec", pos_dec)

        self.dec_blocks = nn.ModuleList([
            TransformerBlock(dec_dim, n_heads_dec) for _ in range(dec_depth)
        ])
        self.dec_norm  = nn.LayerNorm(dec_dim)
        self.dec_head  = nn.Linear(dec_dim, patch_size * patch_size)  # 1-channel patch pixels

    # ── Masking ──────────────────────────────────────────────────────────────

    def random_masking(
        self, x: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        x     : (B, num_patches, D)
        Returns visible tokens, mask (1=masked), ids_restore
        """
        B, L, D = x.shape
        len_keep = int(L * (1 - self.mask_ratio))

        noise         = torch.rand(B, L, device=x.device)
        ids_shuffle   = torch.argsort(noise, dim=1)
        ids_restore   = torch.argsort(ids_shuffle, dim=1)

        ids_keep = ids_shuffle[:, :len_keep]
        x_masked = torch.gather(x, 1, ids_keep.unsqueeze(-1).expand(-1, -1, D))

        mask = torch.ones(B, L, device=x.device)
        mask[:, :len_keep] = 0
        mask = torch.gather(mask, 1, ids_restore)

        return x_masked, mask, ids_restore

    # ── Encode ───────────────────────────────────────────────────────────────

    def encode(
        self, imgs: torch.Tensor, mask: bool = True
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        imgs : (B, 1, H, W)
        Returns (latent, mask, ids_restore)
        """
        B, C, H, W = imgs.shape
        P = self.patch_size

        # Extract all patches as (B*L, 1, P, P)
        patches = patchify(imgs, P)    # (B, L, P*P)
        L       = patches.shape[1]
        patch_imgs = patches.reshape(B * L, 1, P, P)

        # Encode all patches through backbone
        tokens = self.patch_encoder(patch_imgs)        # (B*L, D)
        tokens = tokens.reshape(B, L, self.embed_dim)

        # Add positional embedding
        tokens = tokens + self.pos_embed.unsqueeze(0)

        # Mask
        if mask:
            tokens, mask_bool, ids_restore = self.random_masking(tokens)
        else:
            mask_bool   = torch.zeros(B, L, device=imgs.device)
            ids_restore = torch.arange(L, device=imgs.device).unsqueeze(0).expand(B, -1)

        # Transformer blocks
        for blk in self.enc_blocks:
            tokens = blk(tokens)
        tokens = self.enc_norm(tokens)

        return tokens, mask_bool, ids_restore

    # ── Decode ───────────────────────────────────────────────────────────────

    def decode(
        self,
        latent:      torch.Tensor,
        ids_restore: torch.Tensor,
    ) -> torch.Tensor:
        """
        Inserts mask tokens, adds positional embeddings, decodes.
        Returns pixel values for ALL patches: (B, num_patches, P*P)
        """
        B       = latent.shape[0]
        L       = self.num_patches
        len_vis = latent.shape[1]

        # Project encoder dim → decoder dim
        latent = self.enc_to_dec(latent)                 # (B, vis, dec_dim)

        # Expand mask tokens to fill masked positions
        mask_tokens = self.mask_token.expand(B, L - len_vis, -1)
        full        = torch.cat([latent, mask_tokens], dim=1)   # (B, L, dec_dim)

        # Un-shuffle to original patch order
        idx         = ids_restore.unsqueeze(-1).expand(-1, -1, full.shape[-1])
        full        = torch.gather(full, 1, idx)

        # Add decoder positional embedding
        full = full + self.pos_embed_dec.unsqueeze(0)

        # Decoder blocks
        for blk in self.dec_blocks:
            full = blk(full)
        full = self.dec_norm(full)

        # Predict pixel values per patch
        pred = self.dec_head(full)   # (B, L, P*P)
        return pred

    # ── Loss ─────────────────────────────────────────────────────────────────

    def reconstruction_loss(
        self,
        imgs:       torch.Tensor,  # (B, 1, H, W)
        pred:       torch.Tensor,  # (B, L, P*P)
        mask:       torch.Tensor,  # (B, L) — 1 = was masked
    ) -> torch.Tensor:
        """MSE loss computed only over masked patches (standard MAE)."""
        target = patchify(imgs, self.patch_size)    # (B, L, P*P)
        loss   = F.mse_loss(pred, target, reduction="none")  # (B, L, P*P)
        loss   = loss.mean(dim=-1)                  # (B, L)
        loss   = (loss * mask).sum() / mask.sum()
        return loss

    # ── Forward ──────────────────────────────────────────────────────────────

    def forward(
        self, imgs: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Returns (pred, mask, loss)
        pred : (B, num_patches, P*P) — full reconstruction
        mask : (B, num_patches)       — 1 where masked
        loss : scalar
        """
        latent, mask, ids_restore = self.encode(imgs, mask=True)
        pred = self.decode(latent, ids_restore)
        loss = self.reconstruction_loss(imgs, pred, mask)
        return pred, mask, loss

    # ── Reconstruction helper ─────────────────────────────────────────────────

    @torch.no_grad()
    def reconstruct(self, imgs: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        For visualisation: returns (reconstructed_img, masked_img).
        """
        pred, mask, _ = self.forward(imgs)
        B, H, W = imgs.shape[0], self.img_h, self.img_w

        # Full reconstruction image
        rec_patches = pred                                    # (B, L, P*P)
        rec_img     = unpatchify(rec_patches, self.patch_size, H, W)

        # Build masked input image (set masked patches to 0.5 for display)
        patch_size = self.patch_size
        mask_vis   = mask.unsqueeze(-1).expand(-1, -1, patch_size * patch_size)
        orig_patches = patchify(imgs, patch_size)
        masked_patches = orig_patches * (1 - mask_vis) + 0.5 * mask_vis
        masked_img     = unpatchify(masked_patches, patch_size, H, W)

        return rec_img, masked_img


# ─────────────────────────────────────────────────────────────────────────────
# Fine-tuning head
# ─────────────────────────────────────────────────────────────────────────────

class BirdMAEClassifier(nn.Module):
    """
    Attaches a classification head to a pretrained BirdMAE encoder.
    Uses global average pooling over the visible (all, at inference) tokens.
    """

    def __init__(self, mae: BirdMAE, num_classes: int, dropout: float = 0.3):
        super().__init__()
        self.mae = mae
        self.head = nn.Sequential(
            nn.LayerNorm(mae.embed_dim),
            nn.Dropout(dropout),
            nn.Linear(mae.embed_dim, num_classes),
        )

    def forward(self, imgs: torch.Tensor) -> torch.Tensor:
        # No masking at inference: encode all patches
        latent, _, _ = self.mae.encode(imgs, mask=False)  # (B, L, D)
        pooled = latent.mean(dim=1)                        # (B, D)
        return self.head(pooled)                           # (B, num_classes)


# ─────────────────────────────────────────────────────────────────────────────
# Model factory
# ─────────────────────────────────────────────────────────────────────────────

def build_mae(cfg: dict) -> BirdMAE:
    return BirdMAE(
        img_h           = cfg.get("img_h", 128),
        img_w           = cfg.get("img_w", 224),
        patch_size      = cfg.get("patch_size", 16),
        embed_dim       = cfg.get("embed_dim", 256),
        enc_depth       = cfg.get("enc_depth", 6),
        dec_depth       = cfg.get("dec_depth", 4),
        dec_dim         = cfg.get("dec_dim", 128),
        n_heads_enc     = cfg.get("n_heads_enc", 8),
        n_heads_dec     = cfg.get("n_heads_dec", 4),
        mask_ratio      = cfg.get("mask_ratio", 0.75),
        freeze_backbone = cfg.get("freeze_backbone", False),
    )


def build_classifier(mae: BirdMAE, num_classes: int, cfg: dict) -> BirdMAEClassifier:
    return BirdMAEClassifier(mae, num_classes, dropout=cfg.get("dropout", 0.3))
